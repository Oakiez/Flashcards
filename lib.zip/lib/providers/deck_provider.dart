// ไฟล์: lib/providers/deck_provider.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/deck_model.dart';

class DeckProvider with ChangeNotifier {
  // สร้าง UserProfile เริ่มต้นเพื่อป้องกันค่า Null
  UserProfile user = UserProfile(
    name: 'นักเรียนใหม่ 🌱',
    level: 1,
    coins: 0,
    exp: 0,
    unlockedColors: [0xFFA3C9A8], // สีเริ่มต้น
  );

  List<Deck> _decks = [];
  List<Deck> get decks => _decks;

  DeckProvider() {
    _loadData(); // โหลดข้อมูลทันทีที่เปิดแอป
  }

  // --- ระบบ Save / Load ---
  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    // เซฟข้อมูล UserProfile เป็น JSON
    prefs.setString('userProfile', jsonEncode(user.toJson()));
    // เซฟรายการ Decks ทั้งหมดเป็น JSON
    prefs.setString('decks', jsonEncode(_decks.map((d) => d.toJson()).toList()));
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    
    // โหลดข้อมูล Profile
    if (prefs.containsKey('userProfile')) {
      final String? profileData = prefs.getString('userProfile');
      if (profileData != null) {
        user = UserProfile.fromJson(jsonDecode(profileData));
      }
    }

    // โหลดข้อมูล Decks
    if (prefs.containsKey('decks')) {
      final String? decksData = prefs.getString('decks');
      if (decksData != null) {
        final List decoded = jsonDecode(decksData);
        _decks = decoded.map((d) => Deck.fromJson(d)).toList();
      }
    }
    
    notifyListeners();
  }

  // --- ระบบ Profile (แก้ไขชื่อและรูปภาพ) ---
  
  void updateName(String newName) {
    user.name = newName;
    _saveData();
    notifyListeners();
  }

  void updateProfileImage(String path) {
    user.profileImagePath = path;
    _saveData();
    notifyListeners();
  }

  // --- ระบบร้านค้า (ซื้อสีใหม่) ---
  bool buyColor(int colorValue, int price) {
    if (user.coins >= price && !user.unlockedColors.contains(colorValue)) {
      user.coins -= price;
      user.unlockedColors.add(colorValue);
      _saveData();
      notifyListeners();
      return true; // ซื้อสำเร็จ
    }
    return false; // เงินไม่พอหรือมีสีนี้แล้ว
  }

  // --- ระบบ Reward System (EXP/Coins) ---
  void answerCard(bool remembered) {
    if (remembered) {
      user.exp += 15;
      user.coins += 10; 
      
      // ระบบ Level Up
      if (user.exp >= 100) {
        user.level++;
        user.exp -= 100;
      }
      _saveData();
      notifyListeners();
    }
  }

  // --- ฟังก์ชันจัดการสำรับและการ์ด ---
  
  void addDeck(String title, {int? color, String? imagePath}) {
    _decks.add(Deck(
      id: DateTime.now().toString(), 
      title: title, 
      cards: [], 
      colorValue: color ?? 0xFFA3C9A8, 
      backgroundImagePath: imagePath
    ));
    _saveData(); 
    notifyListeners();
  }

  void editDeck(String deckId, String newTitle, int newColor, String? newImagePath) {
    final index = _decks.indexWhere((d) => d.id == deckId);
    if (index != -1) {
      _decks[index].title = newTitle; 
      _decks[index].colorValue = newColor; 
      _decks[index].backgroundImagePath = newImagePath;
      _saveData(); 
      notifyListeners();
    }
  }

  void deleteDeck(String deckId) {
    _decks.removeWhere((d) => d.id == deckId);
    _saveData(); 
    notifyListeners();
  }

  void addCard(String deckId, String front, String back, {String? frontImg, String? backImg}) {
    final index = _decks.indexWhere((deck) => deck.id == deckId);
    if (index != -1) {
      _decks[index].cards.add(Flashcard(
        id: DateTime.now().toString(), 
        front: front, 
        back: back, 
        frontImagePath: frontImg, 
        backImagePath: backImg
      ));
      _saveData(); 
      notifyListeners();
    }
  }

  void editCard(String deckId, String cardId, String newFront, String newBack, {String? newFrontImg, String? newBackImg}) {
    final dIdx = _decks.indexWhere((d) => d.id == deckId);
    if (dIdx != -1) {
      final cIdx = _decks[dIdx].cards.indexWhere((c) => c.id == cardId);
      if (cIdx != -1) {
        _decks[dIdx].cards[cIdx].front = newFront; 
        _decks[dIdx].cards[cIdx].back = newBack;
        _decks[dIdx].cards[cIdx].frontImagePath = newFrontImg; 
        _decks[dIdx].cards[cIdx].backImagePath = newBackImg;
        _saveData(); 
        notifyListeners();
      }
    }
  }

  void updateSelectedFrame(String? frameName) {
    user.selectedFrame = frameName;
    _saveData();
    notifyListeners();
  }

  void debugAddCoins(int amount) {
    user.coins += amount; // เพิ่มเหรียญตามจำนวนที่ระบุ
    _saveData();         // บันทึกลงเครื่องทันที
    notifyListeners();   // อัปเดตหน้าจอ
  }

  bool buyFrame(String frameName, int price) {
    // เช็คว่าเหรียญพอไหม และยังไม่มีกรอบนี้ใช่ไหม
    if (user.coins >= price && !user.unlockedFrames.contains(frameName)) {
      user.coins -= price;                  // หักเหรียญ
      user.unlockedFrames.add(frameName);   // เพิ่มกรอบเข้ากรุ
      user.selectedFrame = frameName;       // ซื้อปุ๊บ สวมใส่ให้ปั๊บ
      _saveData();                          // เซฟลงเครื่อง
      notifyListeners();                    // อัปเดตหน้าจอ
      return true; // สำเร็จ
    }
    return false; // ไม่สำเร็จ (เหรียญไม่พอ)
  }
}