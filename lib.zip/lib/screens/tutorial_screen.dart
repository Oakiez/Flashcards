// ไฟล์: lib/screens/tutorial_screen.dart
import 'package:flashcards/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TutorialScreen extends StatefulWidget {
  const TutorialScreen({super.key});

  @override
  State<TutorialScreen> createState() => _TutorialScreenState();
}

class _TutorialScreenState extends State<TutorialScreen> {
  final PageController _controller = PageController();
  int _currentPage = 0;

  final List<Map<String, String>> _pages = [
    {
      'title': 'ยินดีต้อนรับ! ✨',
      'desc': 'มาเริ่มต้นเส้นทางการเรียนรู้แบบ Cozy ไปกับเรา สร้างสำรับการ์ดของคุณเองได้ง่ายๆ',
      'icon': '📚'
    },
    {
      'title': 'เรียนรู้ & รับรางวัล 💰',
      'desc': 'ทบทวนการ์ดเพื่อรับ EXP และ Coins ยิ่งตอบถูกมาก ยิ่งเลเวลอัปไวขึ้นนะ!',
      'icon': '🎮'
    },
    {
      'title': 'ตกแต่งตามใจชอบ 🎨',
      'desc': 'นำเหรียญที่ได้ไปซื้อสีพรีเมียมในร้านค้า หรือลบสำรับที่ไม่ใช้แล้วเพื่อจัดระเบียบ',
      'icon': '🛍️'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF9F0),
      body: Stack(
        children: [
          PageView.builder(
            controller: _controller,
            onPageChanged: (index) => setState(() => _currentPage = index),
            itemCount: _pages.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.all(40.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(_pages[index]['icon']!, style: const TextStyle(fontSize: 80)),
                    const SizedBox(height: 40),
                    Text(_pages[index]['title']!, 
                      style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Color(0xFF4A4A4A))),
                    const SizedBox(height: 20),
                    Text(_pages[index]['desc']!, 
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16, color: Colors.grey, height: 1.5)),
                  ],
                ),
              );
            },
          ),
          
          // ตัวบอกตำแหน่งหน้า (Dots) และปุ่มกด
          Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_pages.length, (index) => 
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      height: 10,
                      width: _currentPage == index ? 25 : 10,
                      decoration: BoxDecoration(
                        color: _currentPage == index ? const Color(0xFFA3C9A8) : Colors.grey[300],
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFA3C9A8),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                      ),
                      // ในส่วน onPressed ของปุ่มหน้าสุดท้ายใน TutorialScreen
                      onPressed: () async {
                        if (_currentPage < _pages.length - 1) {
                          _controller.nextPage(duration: const Duration(milliseconds: 500), curve: Curves.ease);
                        } else {
                          // 1. บันทึกข้อมูลลงเครื่อง
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.setBool('isFirstRun', false);

                          // 2. ย้ายไปหน้า HomeScreen (ตรวจสอบชื่อคลาสให้ตรงกับที่ import)
                          if (!mounted) return;
                          Navigator.pushReplacement(
                            context, 
                            MaterialPageRoute(builder: (context) => const HomeScreen()),
                          );
                        }
                      },
                      child: Text(
                        _currentPage == _pages.length - 1 ? 'เริ่มใช้งานเลย!' : 'ถัดไป',
                        style: const TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}