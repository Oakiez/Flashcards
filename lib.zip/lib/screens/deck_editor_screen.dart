// ไฟล์: lib/screens/deck_editor_screen.dart
import 'dart:io';
import 'package:flashcards/screens/study_screen.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../providers/deck_provider.dart';
import '../models/deck_model.dart';

class DeckEditorScreen extends StatefulWidget {
  final String deckId;
  const DeckEditorScreen({super.key, required this.deckId});

  @override
  State<DeckEditorScreen> createState() => _DeckEditorScreenState();
}

class _DeckEditorScreenState extends State<DeckEditorScreen> {
  // 🆕 อัปเดตชุดสี Cozy ให้มีตัวเลือกเยอะขึ้น
  final List<int> _themeColors = [
    0xFFA3C9A8, // เขียวพาสเทล
    0xFFE5B299, // ส้มอิฐ
    0xFFFFD3B6, // พีช
    0xFFB5EAD7, // มิ้นต์
    0xFFC7CEEA, // ม่วงพาสเทล
    0xFFFFDAC1, // ส้มอ่อน
    0xFFFF9AA2, // ชมพูพาสเทล
    0xFFE2F0CB, // เขียวเลมอนอ่อน
    0xFFF6EAC2, // เหลืองครีม
    0xFFD4F0F0, // ฟ้าสว่าง
    0xFFE8DFF5, // ม่วงลาเวนเดอร์
    0xFFFCE1E4, // ชมพูซากุระ
  ];

  Future<String?> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    return pickedFile?.path;
  }

  // 1. Modal สำหรับตั้งค่าสำรับ (ชื่อ, สี, รูป, ลบสำรับ)
  void _showDeckSettingsModal(BuildContext context, Deck deck) {
    final titleController = TextEditingController(text: deck.title);
    int selectedColor = deck.colorValue;
    String? selectedImagePath = deck.backgroundImagePath;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setStateModal) {
          return Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(ctx).viewInsets.bottom,
              left: 20, right: 20, top: 20,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ตั้งค่าสำรับ 🛠️', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(labelText: 'ชื่อสำรับ', border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 16),
                  const Text('เลือกสีธีม:', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  
                  // 🆕 เปลี่ยนมาใช้ Wrap เพื่อให้สีเรียงกันเป็นตารางสวยงาม ไม่ล้นขอบจอ
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: _themeColors.map((color) {
                      return GestureDetector(
                        onTap: () => setStateModal(() => selectedColor = color),
                        child: CircleAvatar(
                          backgroundColor: Color(color),
                          radius: 20,
                          child: selectedColor == color ? const Icon(Icons.check, color: Colors.white) : null,
                        ),
                      );
                    }).toList(),
                  ),
                  
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.image),
                          label: const Text('เลือกรูปพื้นหลัง'),
                          onPressed: () async {
                            final path = await _pickImage();
                            if (path != null) setStateModal(() => selectedImagePath = path);
                          },
                        ),
                      ),
                      if (selectedImagePath != null)
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => setStateModal(() => selectedImagePath = null),
                        )
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFA3C9A8)),
                      onPressed: () {
                        Provider.of<DeckProvider>(context, listen: false).editDeck(
                          deck.id, titleController.text, selectedColor, selectedImagePath,
                        );
                        Navigator.pop(ctx);
                      },
                      child: const Text('บันทึกการตั้งค่า', style: TextStyle(color: Colors.white)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  
                  // 🆕 ปุ่มลบสำรับ
                  SizedBox(
                    width: double.infinity,
                    child: TextButton.icon(
                      icon: const Icon(Icons.delete_forever, color: Colors.redAccent),
                      label: const Text('ลบสำรับนี้', style: TextStyle(color: Colors.redAccent)),
                      onPressed: () {
                        // แจ้งเตือนยืนยันก่อนลบ
                        showDialog(
                          context: context,
                          builder: (dialogCtx) => AlertDialog(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                            title: const Text('ยืนยันการลบ 🗑️'),
                            content: const Text('คุณแน่ใจหรือไม่ว่าต้องการลบสำรับนี้? ข้อมูลการ์ดทั้งหมดในนี้จะหายไปเลยนะ!'),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(dialogCtx), // ปิด Pop-up
                                child: const Text('ยกเลิก', style: TextStyle(color: Colors.grey)),
                              ),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                                onPressed: () {
                                  // สั่งลบ > ปิด Dialog > ปิด Modal > เด้งกลับหน้า Home
                                  Provider.of<DeckProvider>(context, listen: false).deleteDeck(deck.id);
                                  Navigator.pop(dialogCtx); 
                                  Navigator.pop(ctx);
                                  Navigator.pop(context);
                                },
                                child: const Text('ลบเลย', style: TextStyle(color: Colors.white)),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // 2. Modal สำหรับเพิ่ม/แก้ไขการ์ด (ใส่รูปได้) - โค้ดเดิม
  void _showCardEditorModal(BuildContext context, {Flashcard? existingCard}) {
    final frontController = TextEditingController(text: existingCard?.front ?? '');
    final backController = TextEditingController(text: existingCard?.back ?? '');
    String? frontImg = existingCard?.frontImagePath;
    String? backImg = existingCard?.backImagePath;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setStateModal) {
          return Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(ctx).viewInsets.bottom,
              left: 20, right: 20, top: 20,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(existingCard == null ? 'เพิ่มการ์ดใหม่ ✨' : 'แก้ไขการ์ด ✏️', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(12)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('ด้านหน้า (คำถาม)', style: TextStyle(fontWeight: FontWeight.bold)),
                        TextField(controller: frontController, decoration: const InputDecoration(hintText: 'พิมพ์คำถาม...')),
                        const SizedBox(height: 8),
                        frontImg != null 
                          ? Stack(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.file(File(frontImg!), height: 100, width: double.infinity, fit: BoxFit.cover),
                                ),
                                Positioned(right: -10, top: -10, child: IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () => setStateModal(() => frontImg = null)))
                              ],
                            )
                          : TextButton.icon(onPressed: () async { final p = await _pickImage(); if(p != null) setStateModal(()=> frontImg = p); }, icon: const Icon(Icons.add_photo_alternate), label: const Text('เพิ่มรูปคำถาม')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: Colors.green[50], borderRadius: BorderRadius.circular(12)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('ด้านหลัง (คำตอบ)', style: TextStyle(fontWeight: FontWeight.bold)),
                        TextField(controller: backController, decoration: const InputDecoration(hintText: 'พิมพ์คำตอบ...')),
                        const SizedBox(height: 8),
                        backImg != null 
                          ? Stack(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.file(File(backImg!), height: 100, width: double.infinity, fit: BoxFit.cover),
                                ),
                                Positioned(right: -10, top: -10, child: IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () => setStateModal(() => backImg = null)))
                              ],
                            )
                          : TextButton.icon(onPressed: () async { final p = await _pickImage(); if(p != null) setStateModal(()=> backImg = p); }, icon: const Icon(Icons.add_photo_alternate), label: const Text('เพิ่มรูปคำตอบ')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFA3C9A8), padding: const EdgeInsets.symmetric(vertical: 12)),
                      onPressed: () {
                        if (frontController.text.isEmpty && backController.text.isEmpty && frontImg == null && backImg == null) return;
                        final provider = Provider.of<DeckProvider>(context, listen: false);
                        if (existingCard == null) {
                          provider.addCard(widget.deckId, frontController.text, backController.text, frontImg: frontImg, backImg: backImg);
                        } else {
                          provider.editCard(widget.deckId, existingCard.id, frontController.text, backController.text, newFrontImg: frontImg, newBackImg: backImg);
                        }
                        Navigator.pop(ctx);
                      },
                      child: const Text('บันทึกการ์ด', style: TextStyle(color: Colors.white, fontSize: 16)),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<DeckProvider>(context);
    final deckIndex = provider.decks.indexWhere((d) => d.id == widget.deckId);
    
    // ถ้าหาสำรับไม่เจอ (เช่น เพิ่งถูกลบไป) ให้แสดงหน้าว่างๆ ก่อนเด้งกลับ
    if (deckIndex == -1) return const Scaffold(); 
    
    final deck = provider.decks[deckIndex];

    return Scaffold(
     appBar: AppBar(
        title: Text(deck.title),
        backgroundColor: Color(deck.colorValue),
        foregroundColor: Colors.white,
        actions: [
          // 🆕 เพิ่มปุ่ม Play ตรงนี้ครับ
          IconButton(
            icon: const Icon(Icons.play_circle_fill, size: 28),
            onPressed: () {
              // เช็กว่ามีการ์ดในสำรับไหม ถ้าไม่มีจะไม่ให้เล่น
              if (deck.cards.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('ต้องเพิ่มการ์ดอย่างน้อย 1 ใบก่อนถึงจะเล่นได้นะ! 🌟')),
                );
                return;
              }
              // ถ้ามีการ์ด ให้เปิดหน้า StudyScreen
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => StudyScreen(deckId: deck.id)),
              );
            },
          ),
          // ปุ่มตั้งค่า (ของเดิม)
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => _showDeckSettingsModal(context, deck),
          )
        ],
      ),
      body: deck.cards.isEmpty
          ? const Center(child: Text('ยังไม่มีการ์ด\nกดปุ่ม + เพื่อเพิ่มการ์ดใหม่ ✨', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: deck.cards.length,
              itemBuilder: (context, index) {
                final card = deck.cards[index];
                return Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    leading: card.frontImagePath != null 
                        ? ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(card.frontImagePath!), width: 50, height: 50, fit: BoxFit.cover))
                        : Container(width: 50, height: 50, decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.text_fields, color: Colors.grey)),
                    title: Text(card.front.isNotEmpty ? card.front : '[รูปภาพ]', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(card.back.isNotEmpty ? 'คำตอบ: ${card.back}' : 'คำตอบ: [รูปภาพ]', maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: const Icon(Icons.edit, color: Color(0xFFA3C9A8)),
                    onTap: () => _showCardEditorModal(context, existingCard: card),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(deck.colorValue),
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () => _showCardEditorModal(context),
      ),
    );
  }
}