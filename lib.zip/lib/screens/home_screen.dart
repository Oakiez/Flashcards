import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/deck_provider.dart';
import 'deck_editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final deckProvider = Provider.of<DeckProvider>(context);
    final user = deckProvider.user; // ดึงข้อมูล user มาแสดง

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Library 📚'),
        centerTitle: false, // ชิดซ้ายเพื่อให้มีที่วางเลเวล
        actions: [
          // 🆕 แสดง Level
          Container(
            margin: const EdgeInsets.symmetric(vertical: 12),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFA3C9A8).withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFA3C9A8)),
            ),
            child: Text(
              'Lv. ${user.level}',
              style: const TextStyle(color: Color(0xFF4A4A4A), fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ),
          const SizedBox(width: 8),
          // 🆕 แสดง Coins
          Container(
            margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.amber),
            ),
            child: Row(
              children: [
                const Icon(Icons.monetization_on, color: Colors.amber, size: 18),
                const SizedBox(width: 4),
                Text(
                  '${user.coins}',
                  style: const TextStyle(color: Color(0xFF4A4A4A), fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 0.85,
          ),
          itemCount: deckProvider.decks.length,
          itemBuilder: (context, index) {
            final deck = deckProvider.decks[index];
            return Card(
              // ใช้ค่าสีจาก deck ถ้าไม่มีให้ใช้สีเขียวพื้นฐาน (ป้องกัน Error Null)
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => DeckEditorScreen(deckId: deck.id))),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.style, size: 50, color: Color(deck.colorValue ?? 0xFFA3C9A8)), // ป้องกัน Null
                      const SizedBox(height: 12),
                      Text(deck.title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                      Text('${deck.cards.length} Cards', style: const TextStyle(color: Colors.grey)),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFFA3C9A8),
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () => deckProvider.addDeck('สำรับใหม่ 🌟'),
      ),
    );
  }
}