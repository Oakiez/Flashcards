// ไฟล์: lib/screens/study_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/deck_provider.dart';

class StudyScreen extends StatefulWidget {
  final String deckId;
  const StudyScreen({super.key, required this.deckId});

  @override
  State<StudyScreen> createState() => _StudyScreenState();
}

class _StudyScreenState extends State<StudyScreen> {
  int _currentIndex = 0;
  bool _isFlipped = false;
  
  // 🆕 เพิ่มตัวแปรเก็บสะสม EXP และ Coins เฉพาะในรอบการเล่นนี้
  int _sessionExp = 0;
  int _sessionCoins = 0;

  void _nextCard(BuildContext context, bool remembered) {
    // 🆕 ถ้าจำได้ ให้บวกคะแนนสะสมของรอบนี้เพิ่มไว้แสดงตอนจบ
    if (remembered) {
      _sessionExp += 15;
      _sessionCoins += 10;
    }

    // ส่งข้อมูลไปที่ Provider เพื่ออัปเดต Profile จริงๆ
    Provider.of<DeckProvider>(context, listen: false).answerCard(remembered);
    
    final deck = Provider.of<DeckProvider>(context, listen: false).decks.firstWhere((d) => d.id == widget.deckId);
    
    if (_currentIndex < deck.cards.length - 1) {
      // ไปการ์ดใบถัดไป
      setState(() {
        _currentIndex++;
        _isFlipped = false; // รีเซ็ตการพลิกกลับมาด้านหน้า
      });
    } else {
      // 🆕 จบสำรับแล้ว แสดง Pop-up สรุปรางวัลที่ได้ในรอบนี้
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('เก่งมาก! 🎉', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('คุณทบทวนสำรับนี้จบแล้ว', textAlign: TextAlign.center),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.amber.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.amber, width: 2),
                ),
                child: Column(
                  children: [
                    const Text('รางวัลที่ได้รอบนี้ 🎁', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('+ $_sessionExp EXP', style: const TextStyle(fontSize: 18, color: Colors.orange, fontWeight: FontWeight.bold)),
                    Text('+ $_sessionCoins Coins', style: const TextStyle(fontSize: 18, color: Colors.amber, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFA3C9A8), padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12)),
                onPressed: () {
                  Navigator.pop(ctx); // ปิด Pop-up
                  Navigator.pop(context); // เด้งกลับไปหน้าแก้ไขสำรับ
                },
                child: const Text('กลับหน้าหลัก', style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
            )
          ],
        )
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final deck = Provider.of<DeckProvider>(context).decks.firstWhere((d) => d.id == widget.deckId);
    final card = deck.cards[_currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('${deck.title} (${_currentIndex + 1}/${deck.cards.length})'),
        backgroundColor: Color(deck.colorValue),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: () {
                  // กดที่การ์ดเพื่อพลิกดูคำตอบ
                  setState(() {
                    _isFlipped = !_isFlipped;
                  });
                },
                child: Card(
                  elevation: 8,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: _isFlipped ? Colors.green[50] : Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          _isFlipped ? 'ด้านหลัง (คำตอบ)' : 'ด้านหน้า (คำถาม)',
                          style: TextStyle(color: Colors.grey[500], fontSize: 16),
                        ),
                        const SizedBox(height: 20),
                        
                        // แสดงรูปภาพ (ถ้ามี)
                        if (!_isFlipped && card.frontImagePath != null)
                          Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(card.frontImagePath!), fit: BoxFit.contain))),
                        if (_isFlipped && card.backImagePath != null)
                          Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(card.backImagePath!), fit: BoxFit.contain))),
                        
                        const SizedBox(height: 20),
                        // แสดงข้อความ
                        Text(
                          _isFlipped ? card.back : card.front,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            
            // ถ้ายังไม่พลิก ให้บอกให้แตะ
            if (!_isFlipped)
              const Text('แตะที่การ์ดเพื่อดูคำตอบ 👆', style: TextStyle(color: Colors.grey, fontSize: 16)),
              
            // ถ้าพลิกแล้ว ให้แสดงปุ่ม จำได้/ลืม
            if (_isFlipped)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)),
                    icon: const Icon(Icons.close, color: Colors.white),
                    label: const Text('ลืม', style: TextStyle(color: Colors.white, fontSize: 18)),
                    onPressed: () => _nextCard(context, false), // ลืมไม่ได้รางวัล
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFA3C9A8), padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12)),
                    icon: const Icon(Icons.check, color: Colors.white),
                    label: const Text('จำได้', style: TextStyle(color: Colors.white, fontSize: 18)),
                    onPressed: () => _nextCard(context, true), // จำได้ รับรางวัล!
                  ),
                ],
              ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}