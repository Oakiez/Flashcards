// ไฟล์: lib/screens/play_screen.dart
import 'package:flutter/material.dart';
import 'package:flip_card/flip_card.dart';
import 'package:provider/provider.dart';
import '../models/deck_model.dart';
import '../providers/deck_provider.dart';

class PlayScreen extends StatefulWidget {
  final Deck deck;
  const PlayScreen({super.key, required this.deck});

  @override
  State<PlayScreen> createState() => _PlayScreenState();
}

class _PlayScreenState extends State<PlayScreen> {
  int currentIndex = 0;
  bool isFlipped = false; // เช็กว่าการ์ดถูกพลิกหรือยัง
  GlobalKey<FlipCardState> cardKey = GlobalKey<FlipCardState>();

  void _nextCard(bool remembered, BuildContext context) {
    // 1. แจกรางวัลถ้าจำได้
    Provider.of<DeckProvider>(context, listen: false).answerCard(remembered);

    // 2. ไปการ์ดใบถัดไป หรือ จบเกม
    if (currentIndex < widget.deck.cards.length - 1) {
      setState(() {
        isFlipped = false;
        currentIndex++;
      });
      cardKey.currentState?.toggleCard(); // พลิกกลับหน้าเดิม
    } else {
      // เล่นจบสำรับแล้ว
      _showEndGameDialog();
    }
  }

  void _showEndGameDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('เก่งมาก! 🎉', textAlign: TextAlign.center),
        content: const Text('คุณทบทวนสำรับนี้จบแล้ว\nไปพักผ่อนหรือดูโปรไฟล์ของคุณสิ!', textAlign: TextAlign.center),
        actions: [
          Center(
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFA3C9A8)),
              onPressed: () {
                Navigator.pop(context); // ปิด Dialog
                Navigator.pop(context); // ออกจากหน้า PlayScreen
              },
              child: const Text('กลับหน้าหลัก', style: TextStyle(color: Colors.white)),
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final card = widget.deck.cards[currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.deck.title} (${currentIndex + 1}/${widget.deck.cards.length})'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            // หลอด Progress Bar
            LinearProgressIndicator(
              value: (currentIndex + 1) / widget.deck.cards.length,
              backgroundColor: Colors.grey[300],
              color: const Color(0xFFA3C9A8),
              minHeight: 8,
              borderRadius: BorderRadius.circular(4),
            ),
            const SizedBox(height: 40),
            
            Expanded(
              child: FlipCard(
                key: cardKey,
                flipOnTouch: !isFlipped, // ถ้าพลิกแล้ว ห้ามพลิกกลับเอง
                onFlipDone: (isFront) {
                  setState(() {
                    isFlipped = !isFront; // อัปเดตสถานะเมื่อพลิกเสร็จ
                  });
                },
                front: _buildCard(card.front, const Color(0xFFFFFFFF), 'แตะเพื่อดูเฉลย'),
                back: _buildCard(card.back, const Color(0xFFE8F5E9), 'คำตอบคือ...'),
              ),
            ),
            
            const SizedBox(height: 40),

            // แสดงปุ่มก็ต่อเมื่อการ์ดถูกพลิกไปด้านหลังแล้ว
            AnimatedOpacity(
              opacity: isFlipped ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 300),
              child: isFlipped 
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildActionButton(
                        icon: Icons.close_rounded,
                        label: 'ลืม',
                        color: const Color(0xFFE5B299), // สีส้มอิฐ (Cozy)
                        onTap: () => _nextCard(false, context),
                      ),
                      _buildActionButton(
                        icon: Icons.check_rounded,
                        label: 'จำได้',
                        subLabel: '+15 EXP | +5 💰',
                        color: const Color(0xFFA3C9A8), // สีเขียว
                        onTap: () => _nextCard(true, context),
                      ),
                    ],
                  )
                : const SizedBox(height: 70), // จองพื้นที่ว่างไว้กัน UI ขยับ
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(String text, Color bgColor, String hint) {
    return Card(
      color: bgColor,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(32)),
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(hint, style: const TextStyle(color: Colors.grey, fontSize: 14)),
            const SizedBox(height: 16),
            Text(
              text,
              style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFF4A4A4A)),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({required IconData icon, required String label, String? subLabel, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color, width: 2),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
            if (subLabel != null) 
              Text(subLabel, style: TextStyle(color: color, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}