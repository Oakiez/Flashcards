import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/deck_provider.dart';

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});

  // ข้อมูลสินค้าแต่ละประเภท
  final Map<int, int> premiumColors = const {
    0xFFFFD3B6: 50, 0xFFB5EAD7: 50, 0xFFC7CEEA: 100, 0xFFFF9AA2: 150,
  };

  final Map<String, int> avatarFrames = const {
    'กรอบไม้ธรรมชาติ 🪵': 200,
    'กรอบทองคำขาว 💎': 500,
    'กรอบออร่าพาสเทล ✨': 350,
  };

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<DeckProvider>(context);
    final user = provider.user;

    return DefaultTabController(
      length: 2, // แบ่งเป็น 2 หมวด: สี และ อื่นๆ
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Cozy Store 🛍️'),
          actions: [
            Center(
              child: Padding(
                padding: const EdgeInsets.only(right: 16.0),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('💰 ${user.coins}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)),
                ),
              ),
            )
          ],
          bottom: const TabBar(
            indicatorColor: Color(0xFFA3C9A8),
            labelColor: Color(0xFF4A4A4A),
            tabs: [
              Tab(text: 'สีสำรับ'),
              Tab(text: 'กรอบ & ไอเทม'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // --- Tab ที่ 1: สีสำรับ (โค้ดเดิมของคุณที่ปรับให้สวยขึ้น) ---
            _buildColorTab(context, provider),

            // --- Tab ที่ 2: ไอเทมอื่นๆ ---
            _buildItemTab(context, provider),
          ],
        ),
      ),
    );
  }

  Widget _buildColorTab(BuildContext context, DeckProvider provider) {
    return GridView.count(
      padding: const EdgeInsets.all(16),
      crossAxisCount: 3,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      children: premiumColors.entries.map((entry) {
        final isUnlocked = provider.user.unlockedColors.contains(entry.key);
        return _buildStoreTile(
          context,
          color: Color(entry.key),
          price: entry.value,
          isUnlocked: isUnlocked,
          onTap: () => _confirmPurchase(context, provider, entry.key, entry.value),
        );
      }).toList(),
    );
  }

  Widget _buildStoreTile(BuildContext context, {required Color color, required int price, required bool isUnlocked, required VoidCallback onTap}) {
    return InkWell(
      onTap: isUnlocked ? null : onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 5)],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (isUnlocked)
              const Icon(Icons.check_circle, color: Colors.white, size: 30)
            else ...[
              const Icon(Icons.lock, color: Colors.white70, size: 20),
              const SizedBox(height: 4),
              Text('💰 $price', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
            ]
          ],
        ),
      ),
    );
  }

  void _confirmPurchase(BuildContext context, DeckProvider provider, int color, int price) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ยืนยันการซื้อ'),
        content: Text('ต้องการปลดล็อกสีนี้ราคา $price เหรียญใช่ไหม?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ยกเลิก')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              bool success = provider.buyColor(color, price);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(success ? 'ปลดล็อกเรียบร้อย! ✨' : 'เหรียญไม่พอจ้า 🥲')),
              );
            },
            child: const Text('ยืนยัน'),
          )
        ],
      ),
    );
  }

  Widget _buildItemTab(BuildContext context, DeckProvider provider) {
    final user = provider.user;
    
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('กรอบโปรไฟล์พิเศษ 🖼️', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        
        ...avatarFrames.entries.map((entry) {
          final frameName = entry.key;
          final price = entry.value;
          
          // เช็คสถานะว่ามีกรอบนี้หรือยัง? และกำลังใส่อยู่ไหม?
          final isUnlocked = user.unlockedFrames.contains(frameName);
          final isEquipped = user.selectedFrame == frameName;

          return ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person_outline)),
            title: Text(frameName),
            subtitle: Text(isUnlocked ? 'เป็นเจ้าของแล้ว ✨' : 'ราคา $price เหรียญ'),
            trailing: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: isEquipped 
                    ? Colors.grey // สีเทาถ้าใส่อยู่
                    : (isUnlocked ? const Color(0xFFA3C9A8) : null), // สีเขียวถ้าซื้อแล้วรอใส่
              ),
              onPressed: isEquipped 
                ? null // ถ้าใส่อยู่ให้กดไม่ได้
                : () {
                    if (isUnlocked) {
                      // 🟢 กรณีซื้อแล้ว แค่กดเพื่อ 'สวมใส่'
                      provider.updateSelectedFrame(frameName);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('สวมใส่กรอบรูปเรียบร้อย! ✨')),
                      );
                    } else {
                      // 🔴 กรณียังไม่ซื้อ ให้เรียก Pop-up ยืนยันการซื้อ
                      _confirmBuyFrame(context, provider, frameName, price);
                    }
                },
              child: Text(isEquipped ? 'ใช้อยู่' : (isUnlocked ? 'ใช้งาน' : 'ซื้อ')),
            ),
          );
        }).toList(),
      ],
    );
  }

  // 🆕 ฟังก์ชัน Pop-up ยืนยันการซื้อกรอบรูป
  void _confirmBuyFrame(BuildContext context, DeckProvider provider, String frameName, int price) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ยืนยันการซื้อ 🛍️'),
        content: Text('ต้องการซื้อ "$frameName"\nในราคา $price เหรียญ ใช่ไหม?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ยกเลิก')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFA3C9A8)),
            onPressed: () {
              Navigator.pop(ctx); // ปิด popup
              
              // เรียกฟังก์ชันซื้อใน provider
              bool success = provider.buyFrame(frameName, price);
              
              if (success) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('ซื้อและสวมใส่กรอบเรียบร้อย! 🎉')),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('เหรียญไม่พอจ้า 🥲 เก็บเพิ่มอีกนิดนะ')),
                );
              }
            },
            child: const Text('ยืนยัน', style: TextStyle(color: Colors.white)),
          )
        ],
      ),
    );
  }
}