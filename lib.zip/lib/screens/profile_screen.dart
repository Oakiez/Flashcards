import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../providers/deck_provider.dart';
import '../models/deck_model.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  // ฟังก์ชันเลือกรูปภาพจาก Gallery
  Future<void> _pickImage(BuildContext context) async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    
    if (image != null) {
      Provider.of<DeckProvider>(context, listen: false).updateProfileImage(image.path);
    }
  }

  // ฟังก์ชัน Dialog แก้ไขชื่อ
  void _showEditNameDialog(BuildContext context, String currentName) {
    final TextEditingController controller = TextEditingController(text: currentName);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('แก้ไขชื่อของคุณ ✏️'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: "ใส่ชื่อใหม่ที่นี่..."),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ยกเลิก')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFA3C9A8),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () {
              if (controller.text.trim().isNotEmpty) {
                Provider.of<DeckProvider>(context, listen: false).updateName(controller.text.trim());
                Navigator.pop(ctx);
              }
            },
            child: const Text('บันทึก', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // ฟังก์ชันกำหนดสีของกรอบตามที่ตั้งไว้ใน Store
  Color _getFrameColor(String? frameName) {
    switch (frameName) {
      case 'กรอบไม้ธรรมชาติ 🪵': return Colors.brown;
      case 'กรอบทองคำขาว 💎': return Colors.amber;
      case 'กรอบออร่าพาสเทล ✨': return Colors.purpleAccent.shade100;
      default: return Colors.transparent;
    }
  }

  @override
  Widget build(BuildContext context) {
    // ดึงข้อมูล User จาก Provider
    final deckProvider = Provider.of<DeckProvider>(context);
    final user = deckProvider.user;

    return Scaffold(
      backgroundColor: const Color(0xFFFFF9F0), // พื้นหลังโทน Cozy
      appBar: AppBar(
        title: const Text('My Profile 🌱'),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: const Color(0xFF4A4A4A),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              const SizedBox(height: 30),
              
              // --- ส่วนรูปโปรไฟล์และกรอบรูป ---
              _buildAvatarSection(context, user),
              
              const SizedBox(height: 25),
              
              // --- ส่วนชื่อและ Level ---
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(width: 48), // ชดเชยพื้นที่เพื่อให้ชื่ออยู่ตรงกลางพอดี
                  Text(user.name, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF4A4A4A))),
                  IconButton(
                    icon: const Icon(Icons.edit, size: 20, color: Colors.grey),
                    onPressed: () => _showEditNameDialog(context, user.name),
                  ),
                ],
              ),
              Text('Level ${user.level}', style: const TextStyle(fontSize: 18, color: Color(0xFFA3C9A8), fontWeight: FontWeight.bold)),
              
              const SizedBox(height: 35),
              
              // --- การ์ด EXP และ Coins ---
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(child: _buildStatCard('EXP ✨', '${user.exp}/100', Colors.orange)),
                    const SizedBox(width: 15),
                    Expanded(child: _buildStatCard('Coins 💰', '${user.coins}', Colors.amber)),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              // --- ปุ่ม Admin สำหรับ Manual Add Coins (ใช้เทส) ---
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 50),
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.orange,
                    side: const BorderSide(color: Colors.orange),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  icon: const Icon(Icons.add_circle_outline),
                  label: const Text('Debug: +500 Coins'),
                  onPressed: () => deckProvider.debugAddCoins(500),
                ),
              ),

              const SizedBox(height: 20),
              
              // --- ปุ่มถอดกรอบรูป (แสดงเมื่อมีกรอบ) ---
              if (user.selectedFrame != null)
                TextButton.icon(
                  onPressed: () => deckProvider.updateSelectedFrame(null),
                  icon: const Icon(Icons.no_photography_outlined, color: Colors.redAccent),
                  label: const Text('ถอดกรอบรูปออก', style: TextStyle(color: Colors.redAccent)),
                ),

              const SizedBox(height: 40),
              const Text('“ การเรียนรู้คือการเดินทางที่สวยงาม ”', style: TextStyle(color: Colors.grey, fontStyle: FontStyle.italic)),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  // Widget สำหรับสร้าง Avatar Stack
  Widget _buildAvatarSection(BuildContext context, UserProfile user) {
    return Stack(
      alignment: Alignment.center,
      children: [
        // พื้นหลังวงกลมสีขาวเพื่อให้กรอบรูปดูเด่น
        Container(width: 170, height: 170, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
        
        // รูปโปรไฟล์
        CircleAvatar(
          radius: 70,
          backgroundColor: const Color(0xFFA3C9A8),
          backgroundImage: user.profileImagePath != null 
              ? FileImage(File(user.profileImagePath!)) 
              : null,
          child: user.profileImagePath == null 
              ? const Icon(Icons.face_retouching_natural, size: 70, color: Colors.white) 
              : null,
        ),
        
        // กรอบรูป
        if (user.selectedFrame != null)
          Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _getFrameColor(user.selectedFrame), width: 10),
            ),
          ),

        // ปุ่มกล้อง
        Positioned(
          bottom: 5,
          right: 5,
          child: GestureDetector(
            onTap: () => _pickImage(context),
            child: const CircleAvatar(
              backgroundColor: Colors.white,
              radius: 22,
              child: CircleAvatar(
                backgroundColor: Color(0xFFA3C9A8),
                radius: 19,
                child: Icon(Icons.camera_alt, color: Colors.white, size: 20),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Widget สำหรับสร้าง Stat Card
  Widget _buildStatCard(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 15, spreadRadius: 2)],
        border: Border.all(color: color.withOpacity(0.1), width: 2),
      ),
      child: Column(
        children: [
          Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF4A4A4A))),
        ],
      ),
    );
  }
}