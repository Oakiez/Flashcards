import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart'; // อย่าลืมลงแพ็กเกจนี้
import 'package:google_fonts/google_fonts.dart';
import 'providers/deck_provider.dart';
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/tutorial_screen.dart';
import 'screens/store_screen.dart';

void main() async {
  // ต้องมีบรรทัดนี้เพื่อให้เรียกใช้ SharedPreferences ก่อน runApp ได้
  WidgetsFlutterBinding.ensureInitialized();
  
  final prefs = await SharedPreferences.getInstance();
  bool isFirstRun = prefs.getBool('isFirstRun') ?? true;

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DeckProvider()),
      ],
      child: CozyFlashcardApp(isFirstRun: isFirstRun),
    ),
  );
}

class CozyFlashcardApp extends StatelessWidget {
  final bool isFirstRun;
  const CozyFlashcardApp({super.key, required this.isFirstRun});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cozy Flashcards',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFFFF9F0),
        textTheme: GoogleFonts.promptTextTheme(Theme.of(context).textTheme), 
        primaryColor: const Color(0xFFA3C9A8),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFFF9F0),
          elevation: 0,
          iconTheme: IconThemeData(color: Color(0xFF4A4A4A)),
          titleTextStyle: TextStyle(
            color: Color(0xFF4A4A4A), 
            fontSize: 22, 
            fontWeight: FontWeight.bold
          ),
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      // ถ้าเป็นครั้งแรกให้ไปหน้า Tutorial ถ้าไม่ใช่ให้ไป MainNavigation
      home: isFirstRun ? const TutorialScreen() : const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _selectedIndex = 0;

  // 🆕 เพิ่ม StoreScreen() เข้าไปในรายการหน้าจอ
  final List<Widget> _screens = [
    const HomeScreen(),
    const StoreScreen(),
    const ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) => setState(() => _selectedIndex = index),
        selectedItemColor: const Color(0xFFA3C9A8),
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed, // ป้องกันเมนูขยับเวลาความยาวไม่เท่ากัน
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.style), label: 'สำรับ'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'ร้านค้า'), // 🆕 เพิ่มเมนูร้านค้า
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'โปรไฟล์'),
        ],
      ),
    );
  }
}