// ไฟล์: lib/models/deck_model.dart

class Flashcard {
  String id;
  String front;
  String back;
  String? frontImagePath;
  String? backImagePath;

  Flashcard({required this.id, required this.front, required this.back, this.frontImagePath, this.backImagePath});

  Map<String, dynamic> toJson() => {
    'id': id, 'front': front, 'back': back, 'frontImagePath': frontImagePath, 'backImagePath': backImagePath,
  };

  factory Flashcard.fromJson(Map<String, dynamic> json) => Flashcard(
    id: json['id'], 
    front: json['front'] ?? '', 
    back: json['back'] ?? '', 
    frontImagePath: json['frontImagePath'], 
    backImagePath: json['backImagePath'],
  );
}

class Deck {
  String id;
  String title;
  List<Flashcard> cards;
  int colorValue;
  String? backgroundImagePath;

  Deck({required this.id, required this.title, required this.cards, this.colorValue = 0xFFA3C9A8, this.backgroundImagePath});

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'colorValue': colorValue, 'backgroundImagePath': backgroundImagePath,
    'cards': cards.map((c) => c.toJson()).toList(),
  };

  factory Deck.fromJson(Map<String, dynamic> json) => Deck(
    id: json['id'], 
    title: json['title'] ?? 'สำรับไม่มีชื่อ', 
    // 🆕 ถ้าข้อมูลเก่าไม่มีสี (Null) ให้ใช้สีเขียว 0xFFA3C9A8 แทน
    colorValue: json['colorValue'] ?? 0xFFA3C9A8, 
    backgroundImagePath: json['backgroundImagePath'],
    cards: json['cards'] != null ? (json['cards'] as List).map((c) => Flashcard.fromJson(c)).toList() : [],
  );
}

class UserProfile {
  String name;
  int level;
  int exp;
  int coins;
  List<int> unlockedColors;
  String? profileImagePath;
  String? selectedFrame; // กรอบที่ใส่อยู่ตอนนี้
  List<String> unlockedFrames; // รายการกรอบที่ซื้อแล้ว

  UserProfile({
    this.name = 'นักเรียนใหม่ 🌱',
    this.level = 1,
    this.exp = 0,
    this.coins = 0,
    this.selectedFrame,
    List<int>? unlockedColors,
    List<String>? unlockedFrames,
    this.profileImagePath,
  })  : unlockedColors = unlockedColors ?? [0xFFA3C9A8],
        unlockedFrames = unlockedFrames ?? []; // ให้ค่าเริ่มต้นเป็น List ว่าง

  // 1. แก้ไข toJson: เพิ่มข้อมูลกรอบรูปเข้าไปในการ Save
  Map<String, dynamic> toJson() => {
        'name': name,
        'level': level,
        'exp': exp,
        'coins': coins,
        'unlockedColors': unlockedColors,
        'profileImagePath': profileImagePath,
        'selectedFrame': selectedFrame, // 🆕 เพิ่มตัวนี้
        'unlockedFrames': unlockedFrames, // 🆕 เพิ่มตัวนี้
      };

  // 2. แก้ไข fromJson: เพิ่มข้อมูลกรอบรูปเข้าไปในการ Load
  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        name: json['name'] ?? 'นักเรียนใหม่ 🌱',
        level: json['level'] ?? 1,
        exp: json['exp'] ?? 0,
        coins: json['coins'] ?? 0,
        unlockedColors: List<int>.from(json['unlockedColors'] ?? [0xFFA3C9A8]),
        profileImagePath: json['profileImagePath'],
        selectedFrame: json['selectedFrame'], // 🆕 เพิ่มตัวนี้
        unlockedFrames: List<String>.from(json['unlockedFrames'] ?? []), // 🆕 เพิ่มตัวนี้
      );
}